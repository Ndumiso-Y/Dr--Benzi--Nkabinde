Patch: Home layout + icons
- Removes badges row under hero
- Moves About directly under hero
- Qualifications then Memberships, each with relevant icons
- Keeps gallery/map/footer after

Install:
1) Unzip into your project ROOT (same folder that has src/).
2) Allow overwrite of:
   - src/pages/Home.jsx
   - src/components/Icons.jsx
3) Restart dev server: npm run dev
