Patch: Full Qualifications + Memberships

How to install:
1) Unzip this into your project ROOT (same folder that has src/).
2) Allow it to OVERWRITE: src/pages/Home.jsx
3) Restart dev server: npm run dev

Notes:
- Adds complete 'Qualifications' and 'Memberships & Associations' sections.
- Auto-loads all DSC*.jpg images from src/assets into the gallery, sorted by name.
- Keeps your existing hero, about, map, and footer.
