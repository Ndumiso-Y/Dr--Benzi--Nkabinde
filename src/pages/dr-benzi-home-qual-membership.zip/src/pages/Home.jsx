import React from 'react'
import Carousel from '../components/Carousel.jsx'
import QualIcon from '../components/QualIcon.jsx'
import bookCover from '../assets/BookCover.png'
import drPhoto from '../assets/DRBenziRemovedBackground.png'

// Auto-load all DSC*.jpg images from assets for the gallery
const gallery = Object
  .values(import.meta.glob('../assets/DSC*.{jpg,JPG,jpeg,JPEG}', { eager: true, import: 'default' }))
  .sort((a,b) => a.localeCompare(b))

export default function Home(){
  const qualsIcons = [
    { label: 'MBChB (Medicine)', svgPath: 'M12 2l7 4v6c0 5-3 8-7 10C8 20 5 17 5 12V6l7-4z' },
    { label: 'FCOG (SA) – O&G', svgPath: 'M12 2a7 7 0 100 14 7 7 0 000-14zm0 3v5m0 4h.01' },
    { label: '34+ Years in Women\'s Health', svgPath: 'M4 7h16M7 4v16m10-9l-3 3-2-2-3 3' },
  ]

  return (<div>
    {/* Hero */}
    <section className="relative bg-brand-navy">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-10 items-center px-6 py-16">
        <div className="order-2 md:order-1 text-white">
          <h1 className="text-4xl md:text-6xl font-extrabold text-brand-cream leading-tight">CHOOSE WELL<br/>CHOOSE LIFE</h1>
          <p className="mt-4 text-brand-cream/90">A GUIDE TO A PURPOSE-FILLED LIFE FOR SOUTH AFRICAN TEENAGERS</p>
          <div className="mt-6 flex gap-3">
            <a href="#/book" className="px-5 py-3 bg-brand-dark text-brand-cream rounded-md font-semibold">ABOUT BOOK</a>
            <a href="#/order" className="px-5 py-3 bg-brand-orange text-white rounded-md font-semibold">BUY BOOK</a>
          </div>
        </div>
        <div className="order-1 md:order-2">
          <img src={bookCover} alt="Book Cover" className="w-full max-w-md mx-auto rounded-xl shadow-xl object-contain bg-white"/>
        </div>
      </div>
    </section>

    {/* Quick badges row (icons) */}
    <section className="max-w-6xl mx-auto px-6 py-12">
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {qualsIcons.map(q => <QualIcon key={q.label} label={q.label} svgPath={q.svgPath} />)}
      </div>
    </section>

    {/* FULL Qualifications (cards) */}
    <section className="bg-brand-navy text-brand-cream py-16">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl font-bold mb-10 flex items-center gap-3">
          Qualifications
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
            <path d="M12 2l7 4v6c0 5-3 8-7 10C8 20 5 17 5 12V6l7-4z" stroke="#F2EED9" strokeWidth="1.5" />
          </svg>
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { title: "MB.ChB (KZN)", desc: "Bachelor of Medicine and Bachelor of Surgery. University of KwaZulu-Natal." },
            { title: "FCOG (SA)", desc: "Fellow of the College of Obstetricians and Gynaecologists of South Africa. College of Medicine of South Africa." },
            { title: "MBA (Bond Univ)", desc: "Masters in Business Administration (MBA), Bond University Australia." },
            { title: "DGM (SA)", desc: "Diploma in General Management, University of South Africa." },
            { title: "Dip Obst (SA)", desc: "Diploma in Obstetrics, College of Medicine of South Africa." },
          ].map((q) => (
            <div key={q.title} className="bg-brand-dark/30 p-8 rounded-xl text-center shadow-sm border border-white/10 hover:bg-brand-dark/50 transition">
              <h3 className="text-xl font-bold">{q.title}</h3>
              <p className="mt-3 text-sm text-brand-cream/90">{q.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* About + photo */}
    <section className="max-w-6xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-8 items-center">
      <div>
        <h3 className="text-xl md:text-2xl font-semibold">About Dr Benzi</h3>
        <p className="mt-4 text-gray-700">Dr Benzile Monica Fakazile Nkabinde is a specialist obstetrician/gynaecologist with 34 years dedicated to women’s health, a mother of five, and author of <em>Choose Well, Choose Life</em> — a guide to help South African teenagers make purpose-filled choices.</p>
        <a href="#/about" className="inline-block mt-4 px-4 py-2 rounded-md bg-brand-navy text-white">Read More</a>
      </div>
      <div className="flex justify-center">
        <img src={drPhoto} alt="Dr Benzi" className="h-80 object-contain drop-shadow-2xl"/>
      </div>
    </section>

    {/* Memberships & Associations */}
    <section className="bg-brand-navy text-brand-cream py-16">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl font-bold mb-10 underline underline-offset-4">Memberships & Associations</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { title: "SASOG", desc: "South African Society of Obstetricians & Gynaecologists" },
            { title: "SASUOG", desc: "South African Society of Ultrasound in Obstetrics and Gynaecology" },
            { title: "GMG", desc: "Gynaecology Management Group" },
            { title: "SAMS", desc: "South African Menopause Society" },
            { title: "SAMA", desc: "South African Medical Association" },
          ].map((m) => (
            <div key={m.title} className="bg-brand-dark/30 p-8 rounded-xl text-center shadow-sm border border-white/10 hover:bg-brand-dark/50 transition">
              <h3 className="text-xl font-bold">{m.title}</h3>
              <p className="mt-3 text-sm text-brand-cream/90">{m.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* Carousel */}
    <section className="max-w-6xl mx-auto px-6 py-12">
      <h3 className="text-xl md:text-2xl font-semibold mb-4">Gallery</h3>
      <Carousel images={gallery} autoplay interval={3000} />
    </section>

    {/* Map */}
    <section className="max-w-6xl mx-auto px-6 pb-16">
      <h3 className="text-xl md:text-2xl font-semibold mb-4">Find Us</h3>
      <div className="rounded-xl overflow-hidden border">
        <iframe title="Map" src="https://www.google.com/maps?q=17%20South%20Road,%20Lindhaven,%20Roodepoort%201724&output=embed" width="100%" height="380" style={{border:0}} loading="lazy" allowFullScreen></iframe>
      </div>
    </section>

    {/* Footer */}
    <footer className="bg-gray-100 border-t">
      <div className="max-w-6xl mx-auto px-6 py-8 grid md:grid-cols-2 gap-6 text-sm">
        <div>
          <p>© {new Date().getFullYear()} Dr. MF Nkabinde</p>
          <p>17 South Road, Lindhaven, Roodepoort 1724</p>
          <p>WhatsApp +27 76 421 9522</p>
          <p><a className="text-blue-600" href="mailto:drnkabindedigital@gmail.com">drnkabindedigital@gmail.com</a></p>
        </div>
        <div className="md:text-right">
          <a className="text-blue-700 hover:underline" href="https://www.facebook.com/share/15yeqSp7xx/" target="_blank" rel="noreferrer">Facebook</a>
        </div>
      </div>
    </footer>
  </div>)
}
